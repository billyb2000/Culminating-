
import java.io.BufferedReader;
import java.io.BufferedWriter;
import java.io.FileNotFoundException;
import java.io.FileReader;
import java.io.FileWriter;
import java.io.IOException;
import java.util.ArrayList;

/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */

/**
 *
 * @author Felix
 */
public class HospitalData {
    public static ArrayList<TimedPatient> activePatientsER = new ArrayList<>();
    public static ArrayList<TimedPatient> activePatientsWI = new ArrayList<>();
    public static ArrayList<TimedPatient> completedPatientsER = new ArrayList<>();
    public static ArrayList<TimedPatient> completedPatientsWI = new ArrayList<>();
    
    // generate patient id
    public static String generatePatientId(String first, String last, int age, String sex) {

        char firstInitial = Character.toUpperCase(first.charAt(0));
        char lastInitial = Character.toUpperCase(last.charAt(0));

        String ageStr = String.valueOf(age);
        while (ageStr.length() < 3) {
            ageStr = "0" + ageStr;
        }

        char sexChar;
        if (sex.equalsIgnoreCase("Male")) {
            sexChar = 'M';
        } else if (sex.equalsIgnoreCase("Female")) {
            sexChar = 'F';
        } else {
            sexChar = 'O';
        }
        
        long ending = System.currentTimeMillis() % 1000;

        return "" + firstInitial + lastInitial + ageStr + sexChar + "-" + ending;
    }
    
    public static boolean checkIds(String id) {
        if (id == null || id.isEmpty()) { return false; }

        for (TimedPatient p : activePatientsER) {
            if (id.equalsIgnoreCase(p.getPatientId())) { return true; }
        }
        for (TimedPatient p : activePatientsWI) {
            if (id.equalsIgnoreCase(p.getPatientId())) { return true; }
        }

        return false;
    }
    
    // search method
    public static TimedPatient findPatient(String input) {
        if (input == null) { return null; }
        if (input.isEmpty()) { return null; }

        for (TimedPatient p : activePatientsER) {
            if (matches(p, input)) return p;
        }
        
        for (TimedPatient p : activePatientsWI) {
            if (matches(p, input)) return p;
        }
        
        return null;
    }
    
    private static boolean matches(TimedPatient p, String input) {
        if (p == null) {
            return false;
        }

        if (p.getPatientId() != null && p.getPatientId().equalsIgnoreCase(input)) {
            return true;
        }

        String full = p.getFullName().trim();
        return full.equalsIgnoreCase(input);
    }
    
    // sort method
    private static int statusRank(String status) {
        if (status == null) { return 0; }

        if (status.equalsIgnoreCase("Treating")) return 2;
        if (status.equalsIgnoreCase("Waiting"))  return 1;

        return 0;
    }
    
    private static boolean swap(TimedPatient a, TimedPatient b) {

        int ra = statusRank(a.getStatus());
        int rb = statusRank(b.getStatus());

        if (ra != rb) {
            return ra < rb;
        }

        if (a.getPriority() != b.getPriority()) {
            return a.getPriority() < b.getPriority();
        }

        return a.getTimeWaiting() < b.getTimeWaiting();
    }
    
    public static void sortPatients(ArrayList<TimedPatient> patients) {
        for (int i = 0; i < patients.size() - 1; i++) {
            for (int j = i + 1; j < patients.size(); j++) {

                TimedPatient p1 = patients.get(i);
                TimedPatient p2 = patients.get(j);

                if (swap(p1, p2)) {
                    patients.set(i, p2);
                    patients.set(j, p1);
                }
            }
        }
    }
    
    public static void sortActivePatients() {
        sortPatients(activePatientsER);
        sortPatients(activePatientsWI);
    }
    
    // read and write
    public static void saveActivePatients(String fileName) throws IOException {

        BufferedWriter out = new BufferedWriter(new FileWriter(fileName));

        for (TimedPatient p : activePatientsER) {
            out.write(p.toFileString());
            out.newLine();
        }

        for (TimedPatient p : activePatientsWI) {
            out.write(p.toFileString());
            out.newLine();
        }

        out.close();
    }
    
    public static void loadActivePatients(String fileName) throws FileNotFoundException, IOException {
        BufferedReader read = new BufferedReader(new FileReader(fileName));
        String line;

        while ((line = read.readLine()) != null) {

            String[] d = line.split(",");

            String type = d[0];

            TimedPatient p;

            if (type.equalsIgnoreCase("ER")) {
                p = new TimedPatient(
                                    d[0],
                                    d[2],
                                    d[3],
                                    Integer.parseInt(d[4]),
                                    d[5],
                                    d[6],
                                    Integer.parseInt(d[7])
                );

                activePatientsER.add(p);

            } else {
                p = new TimedPatient(
                                    d[0],
                                    d[2],
                                    d[3],
                                    Integer.parseInt(d[4]),
                                    d[5],
                                    d[6],
                                    Integer.parseInt(d[7])
                );

                activePatientsWI.add(p);
            }

            p.setPatientId(d[1]);
            p.setStatus(d[8]);

            p.setCreatedTime(Long.parseLong(d[9]));
            p.setStartTime(Long.parseLong(d[10]));
            p.setEndTime(Long.parseLong(d[11]));
        }
        
        read.close();
    }
}
