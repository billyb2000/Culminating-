

/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */

/**
 *
 * @author Felix
 */
public class TimedPatient extends Patient{
    
    private long createdTime;
    private long startTime;
    private long endTime; 
    
    private String status;

    public TimedPatient(String type,
                        String first,
                        String last,
                        int age,
                        String sex,
                        String reason,
                        int priority) {

        super(type, first, last, age, sex, reason, priority);
        
        createdTime = System.currentTimeMillis();
        startTime = -1;
        endTime = -1;
        
        this.status = "Waiting";
    }

    // status
    public void setStatus(String status) {
        this.status = status;
    }
    
    public String getStatus() {
        return status;
    }
    
    // time
    
    public boolean hasStarted() {
        return startTime != -1;
    }

    public boolean isCompleted() {
        return endTime != -1;
    }

    public void markStarted() {
        if (!hasStarted() && !isCompleted()) {
            startTime = System.currentTimeMillis();
            setStatus("Treating");
        }
    }

    public void markCompleted() {
        if (hasStarted() && !isCompleted()) {
            endTime = System.currentTimeMillis();
            setStatus("Completed");
        }
    }

    public long getTimeWaiting() {
        if (hasStarted()) {
            return startTime - createdTime;
        }
        return System.currentTimeMillis() - createdTime;
    }

    public long getTimeTreating() {
        if (!hasStarted()) return 0;

        if (isCompleted()) {
            return endTime - startTime;
        }
        return System.currentTimeMillis() - startTime;
    }

    public String getWaitingTimeText() {
        return formatTime(getTimeWaiting());
    }

    public String getTreatingTimeText() {
        return formatTime(getTimeTreating());
    }

    private String formatTime(long ms) {
        long totalSeconds = ms / 1000;
        long seconds = totalSeconds % 60;
        long totalMinutes = totalSeconds / 60;
        long minutes = totalMinutes % 60;
        long hours = totalMinutes / 60;

        if (hours > 0) {
            return hours + ":" + twoDigits(minutes) + ":" + twoDigits(seconds);
        }
        return minutes + ":" + twoDigits(seconds);
    }

    private String twoDigits(long n) {
        if (n < 10) return "0" + n;
        return "" + n;
    }
    
    public String toDisplayRow() {
        String col1 = padRight(getStatus(), 10);
        String col2 = padLeft("" + getPriority(), 8);
        String col3 = padRight(getPatientId(), 10);
        String col4 = padRight(getFullName(), 30);
        String col5 = padLeft("" + getAge(), 3);

        return col1 + " | " + col2 + " | " + col3 + " | " + col4 + " | " + col5;
    }
    
    public String toDisplayRowWithTime() {
        String col1 = padRight(getStatus(), 10);
        String col2 = padLeft("" + getPriority(), 8);
        String col3 = padRight(getPatientId(), 10);
        String col4 = padRight(getFullName(), 30);
        String col5 = padLeft("" + getAge(), 3);
        String col6 = padLeft(getWaitingTimeText(), 9);
        String col7 = padLeft(getTreatingTimeText(), 9);

        return col1 + " | " + col2 + " | " + col3 + " | " + col4 + " | " + col5 + " | " + col6 + "  | " + col7;
    }

    private String padRight(String s, int width) {
        if (s.length() >= width) {
            return s.substring(0, width);
        }

        while (s.length() < width) s += " ";
        return s;
    }

    private String padLeft(String s, int width) {
        if (s.length() >= width) { 
            return s.substring(0, width);
        }

        while (s.length() < width) s = " " + s;
        return s;
    }
    
    // read/write
    public long getCreatedTime() {
        return createdTime;
    }
    
    public long getStartTime() {
        return startTime;
    }
    
    public long getEndTime() {
        return endTime;
    }
    
    public void setCreatedTime(long createdTime) {
        this.createdTime = createdTime;
    }
    
    public void setStartTime(long startTime) {
        this.startTime = startTime;
    }
    
    public void setEndTime(long endTime) {
        this.endTime = endTime;
    }
    
    
    public String toFileString() {
        return getType() + "," +
               getPatientId() + "," +
               getFirst() + "," +
               getLast() + "," +
               getAge() + "," +
               getSex() + "," +
               getReason() + "," +
               getPriority() + "," +
               getStatus() + "," +
               getCreatedTime() + "," +
               getStartTime() + "," +
               getEndTime();
    }
}
