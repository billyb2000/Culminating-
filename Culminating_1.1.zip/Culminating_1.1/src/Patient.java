/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */

/**
 *
 * @author Felix
 */
public class Patient {

    private String patientId;
    private String type;
    private String first;
    private String last;
    private int age;
    private String sex;
    private String reason;
    private int priority;

    public Patient(String type,
                   String first,
                   String last,
                   int age,
                   String sex,
                   String reason,
                   int priority) {

        this.patientId = "";
        this.type = type;
        this.first = first;
        this.last = last;
        this.age = age;
        this.sex = sex;
        this.reason = reason;
        this.priority = priority;
    }

    // getters
    public String getPatientId() { return patientId; }
    public String getType() { return type; }

    public String getFirst() { return first; }
    public String getLast() { return last; }
    public String getFullName() {
        return (first + " " + last).trim();
    }
    public int getAge() { return age; }
    public String getSex() { return sex; }
    public String getReason() { return reason; }
    public int getPriority() { return priority; }

    // setters
    public void setPatientId(String patientId) { this.patientId = patientId; }
    public void setFirst(String first) { this.first = first; }
    public void setLast(String last) { this.last = last; }
    public void setAge(int age) { this.age = age; }
    public void setSex(String sex) { this.sex = sex; }
    public void setReason(String reason) { this.reason = reason; }
    public void setPriority(int priority) { this.priority = priority; }
}
